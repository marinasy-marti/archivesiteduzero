#ifndef DEF_ZSTRING
#define DEF_ZSTRING

#include <iostream>

class ZString
{
    public:
        ZString();
        ZString(const char *chaine);
        ZString(const ZString &chaine);
        ~ZString();
        int longueur(const char *chaine);
        char *copie(const char *chaine);
        void afficher();
        ZString operator=(const char *chaine);
        ZString operator=(const ZString &chaine);
        ZString operator+(const char *chaine);
        ZString operator+(const ZString &chaine);
        char *getChaine();

    private:
        char *m_chaine;
        int m_longueur;
};

std::ostream &operator<<( std::ostream &out, ZString &chaine );

#endif
