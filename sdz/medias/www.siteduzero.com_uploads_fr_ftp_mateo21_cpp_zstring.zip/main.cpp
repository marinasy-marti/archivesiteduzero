#include <iostream>
#include "ZString.h"

using namespace std;

int main()
{
    ZString chaine("Bonjour");
    ZString nom = "Mateo"; // Cette fa�on d'initialisation revient au m�me
    ZString resultat;

    resultat = chaine + " " + nom;

    cout << "Le resultat vaut maintenant : " << resultat << endl;

    return 0;
}
