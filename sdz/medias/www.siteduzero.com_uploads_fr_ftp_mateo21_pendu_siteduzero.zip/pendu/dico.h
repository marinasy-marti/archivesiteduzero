/*
Jeu du pendu
Par M@teo21, pour le Site du Z�r0
www.siteduzero.com

dico.h
------

Contient les prototypes des fonctions de dico.c
*/


#ifndef DEF_DICO
#define DEF_DICO


int piocherMot(char *motPioche);
int nombreAleatoire(int nombreMax);

#endif

