﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.ComponentModel;
using ODataStackOverflow.StackOverflowReference;
using System.Data.Services.Client;

namespace ODataStackOverflow
{
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        private DataServiceCollection<User> utilisateurs;
        public DataServiceCollection<User> Utilisateurs
        {
            get
            {
                return utilisateurs;
            }
            set
            {
                if (value == utilisateurs)
                    return;
                utilisateurs = value;
                NotifyPropertyChanged("Utilisateurs");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string nomPropriete)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(nomPropriete));
        }

        // Constructeur
        public MainPage()
        {
            InitializeComponent();

            Entities service = new Entities(new Uri("http://data.stackexchange.com/stackoverflow/atom"));

            IQueryable<User> requete = from utilisateur in service.Users
                                       orderby utilisateur.Reputation descending
                                       select utilisateur;


            Utilisateurs = new DataServiceCollection<User>();
            Utilisateurs.LoadAsync(requete.Take(10));
        }
    }
}