﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Device.Location;
using System.ComponentModel;
using Microsoft.Phone.Controls.Maps;

namespace TableauBordGeoloc
{
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        private GeoCoordinateWatcher watcher;
        private double vitesseMax;
        private Pushpin pushPin;

        private IEnumerable<GeoCoordinate> maListeDePositions;
        public IEnumerable<GeoCoordinate> MaListeDePositions
        {
            get
            {
                return maListeDePositions;
            }
            set
            {
                if (value == maListeDePositions)
                    return;
                maListeDePositions = value;
                NotifyPropertyChanged("MaListeDePositions");
            }
        }

        private GeoCoordinate maPosition;
        public GeoCoordinate MaPosition
        {
            get
            {
                return maPosition;
            }
            set
            {
                if (value == maPosition)
                    return;
                maPosition = value;
                NotifyPropertyChanged("MaPosition");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string nomPropriete)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(nomPropriete));
        }


        public MainPage()
        {
            InitializeComponent();
            watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
            watcher.StatusChanged += new System.EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
            watcher.PositionChanged += new System.EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            watcher.Start();
            map1.ZoomLevel = 15;
            //map1.Mode = new AerialMode();

            DataContext = this;
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            watcher.Stop();
            base.OnBackKeyPress(e);
        }

        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            Dispatcher.BeginInvoke(() => statut.Text = "Statut : " + e.Status.ToString());
        }

        private void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                double vit = double.IsNaN(e.Position.Location.Speed) ? 0 : (e.Position.Location.Speed / 1000 * 3600);
                if (vit > vitesseMax)
                    vitesseMax = vit;
                vitesse.Text = "Vitesse (km/h) : " + vit;
                vitesseMaxi.Text = "Vitesse maxi (km/h) : " + vitesseMax;
                orientation.Text = GetOrientation(e.Position.Location.Course);

                map1.Center = e.Position.Location;

                MaListeDePositions = new List<GeoCoordinate> { e.Position.Location };
                MaPosition = e.Position.Location;
            });
        }

        private string GetOrientation(double angle)
        {
            if (double.IsNaN(angle))
                return string.Empty;
            if (angle >= 337 || angle <= 22)
                return "N";
            if (angle >= 23 && angle <= 67)
                return "NE";
            if (angle >= 68 && angle <= 112)
                return "E";
            if (angle >= 113 && angle <= 157)
                return "SE";
            if (angle >= 158 && angle <= 202)
                return "S";
            if (angle >= 203 && angle <= 247)
                return "SO";
            if (angle >= 248 && angle <= 292)
                return "O";
            return "NO";
        }
    }
}
