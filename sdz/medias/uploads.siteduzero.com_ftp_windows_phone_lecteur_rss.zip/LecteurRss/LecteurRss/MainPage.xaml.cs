﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.ComponentModel;
using System.IO;
using Microsoft.Phone.Tasks;
using System.Xml;
using System.ServiceModel.Syndication;
using System.Windows.Data;
using System.Globalization;

namespace LecteurRss
{
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        private IEnumerable<Flux> listeDeFlux;
        public IEnumerable<Flux> ListeDeFlux
        {
            get
            {
                return listeDeFlux;
            }
            set
            {
                if (value == listeDeFlux)
                    return;
                listeDeFlux = value;
                NotifyPropertyChanged("ListeDeFlux");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string nomPropriete)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(nomPropriete));
        }

        private WebClient client;
        private List<SyndicationFeed> listeFlux;

        // Constructeur
        public MainPage()
        {
            InitializeComponent();
            listeFlux = new List<SyndicationFeed>();

            client = new WebClient();
            client.DownloadStringCompleted += client_DownloadStringCompleted;
            client.DownloadStringAsync(new Uri("http://www.siteduzero.com/Templates/xml/news_fr.xml"), "SDZ");

            DataContext = this;
        }

        private void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if ((string)e.UserState == "SDZ")
                {
                    // ce sont les données venant du flux du site du zéro
                    AjouteFlux(e.Result);

                    // lancer le téléchargement suivant
                    client.DownloadStringAsync(new Uri("http://windowsteamblog.com/windows_phone/b/windowsphone/rss.aspx"), "WP7");
                }
                if ((string)e.UserState == "WP7")
                {
                    // ce sont les données venant du flux blog de l'équipe windows phone
                    AjouteFlux(e.Result);
                    ListeDeFlux = CreerLeFlux(listeFlux);
                }
            }
        }

        private IEnumerable<Flux> CreerLeFlux(List<SyndicationFeed> liste)
        {
            foreach (SyndicationFeed flux in liste)
            {
                Flux f = new Flux
                {
                    Titre = flux.Title.Text,
                    Elements = CreerElements(flux.Items)
                };
                yield return f;
            }
        }

        private IEnumerable<Elements> CreerElements(IEnumerable<SyndicationItem> elements)
        {
            foreach (SyndicationItem element in elements)
            {
                SyndicationLink lien = element.Links.FirstOrDefault();

                Elements e = new Elements
                {
                    Titre = element.Title.Text,
                    Url = lien == null ? null : lien.Uri
                };
                yield return e;
            }
        }


        private void AjouteFlux(string flux)
        {
            StringReader stringReader = new StringReader(flux);
            XmlReader xmlReader = XmlReader.Create(stringReader);
            SyndicationFeed feed = SyndicationFeed.Load(xmlReader);
            listeFlux.Add(feed);
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox listBox = sender as ListBox;

            if (listBox != null && listBox.SelectedItem != null)
            {
                Elements elementChoisi = (Elements)listBox.SelectedItem;
                if (elementChoisi.Url != null)
                {
                    WebBrowserTask webBrowserTask = new WebBrowserTask();
                    webBrowserTask.Uri = elementChoisi.Url;
                    listBox.SelectedItem = null;
                    webBrowserTask.Show();
                }
            }
        }
    }
}