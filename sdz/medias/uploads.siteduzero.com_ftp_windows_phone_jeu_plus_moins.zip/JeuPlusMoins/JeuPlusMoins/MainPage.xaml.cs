﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.ComponentModel;
using Microsoft.Phone.Shell;

namespace JeuPlusMoins
{
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        private Random random;
        private int valeurSecrete;
        private int nbCoups;

        private string valeur;
        public string Valeur
        {
            get
            {
                return valeur;
            }
            set
            {
                if (value == valeur)
                    return;
                valeur = value;
                NotifyPropertyChanged("Valeur");
            }
        }

        private string indication;
        public string Indication
        {
            get
            {
                return indication;
            }
            set
            {
                if (value == indication)
                    return;
                indication = value;
                NotifyPropertyChanged("Indication");
            }
        }

        private string nombreDeCoup;
        public string NombreDeCoups
        {
            get
            {
                return nombreDeCoup;
            }
            set
            {
                if (value == nombreDeCoup)
                    return;
                nombreDeCoup = value;
                NotifyPropertyChanged("NombreDeCoups");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string nomPropriete)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(nomPropriete));
        }

        public MainPage()
        {
            InitializeComponent();
            random = new Random();
            valeurSecrete = random.Next(1, 500);
            nbCoups = 0;

            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PhoneApplicationService.Current.State["message"] = "Je viens de trouver le nombre secret en " + nombreDeCoup;
            NavigationService.Navigate(new Uri("/LoginFacebook.xaml", UriKind.Relative)); ;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int num;
            if (int.TryParse(Valeur, out num))
            {
                if (valeurSecrete == num)
                {
                    Indication = "Gagné !!";
                    boutonVerifier.IsEnabled = false;
                    bouton.IsEnabled = true;
                }
                else
                {
                    nbCoups++;
                    if (valeurSecrete < num)
                        Indication = "Trop grand ...";
                    else
                        Indication = "Trop petit ...";
                    if (nbCoups == 1)
                        NombreDeCoups = nbCoups + " coup";
                    else
                        NombreDeCoups = nbCoups + " coups";
                }
            }
            else
                Indication = "Veuillez saisir un entier ...";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            nbCoups = 0;
            boutonVerifier.IsEnabled = true;
            bouton.IsEnabled = false;
            Valeur = string.Empty;
            Indication = string.Empty;
            NombreDeCoups = string.Empty;
        }
    }
}