﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Facebook;
using Microsoft.Phone.Shell;

namespace JeuPlusMoins
{
    public partial class LoginFacebook : PhoneApplicationPage
    {
        private FacebookClient client;

        public LoginFacebook()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            Connect();
        }

        private void Connect()
        {
            but.IsEnabled = false;
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters["response_type"] = "token";
            parameters["display"] = "touch";
            parameters["scope"] = "user_about_me, friends_about_me, user_birthday, friends_birthday, publish_stream";
            parameters["redirect_uri"] = "https://www.facebook.com/connect/login_success.html";
            parameters["client_id"] = "votre appid";

            client = new FacebookClient();
            Uri uri = client.GetLoginUrl(parameters);

            wb.Visibility = Visibility.Visible;
            wb.Navigate(uri);
        }

        private void wb_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            FacebookOAuthResult result;
            if (client.TryParseOAuthCallbackUrl(e.Uri, out result))
            {
                if (result.IsSuccess)
                {
                    string token = result.AccessToken;
                    client = new FacebookClient(token);
                    client.PostCompleted += new EventHandler<FacebookApiEventArgs>(c_PostCompleted);
                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    parameters["message"] = (string)PhoneApplicationService.Current.State["message"];
                    client.PostAsync("https://graph.facebook.com/me/feed", parameters);
                }
                else
                    but.IsEnabled = true;
                wb.Visibility = Visibility.Collapsed;
            }
        }

        private void wb_NavigationFailed(object sender, System.Windows.Navigation.NavigationFailedEventArgs e)
        {
            but.IsEnabled = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Connect();
        }

        private void c_PostCompleted(object sender, FacebookApiEventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                if (e.Error == null)
                    MessageBox.Show("Message correctement posté");
                else
                    MessageBox.Show("Impossible de poster le message");
                if (NavigationService.CanGoBack)
                    NavigationService.GoBack();
            });
        }
    }
}