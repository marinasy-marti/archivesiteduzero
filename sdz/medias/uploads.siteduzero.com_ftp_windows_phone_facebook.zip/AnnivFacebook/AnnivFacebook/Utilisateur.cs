﻿using System.Windows.Media.Imaging;

namespace AnnivFacebook
{
    public class Utilisateur
    {
        public string Id { get; set; }
        public string Nom { get; set; }
        public BitmapImage Image { get; set; }
        public string DateNaissance { get; set; }
    }
}
