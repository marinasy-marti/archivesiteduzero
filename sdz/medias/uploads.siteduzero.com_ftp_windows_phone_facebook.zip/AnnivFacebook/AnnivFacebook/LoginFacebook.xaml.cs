﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Facebook;
using Microsoft.Phone.Shell;

namespace AnnivFacebook
{
    public partial class LoginFacebook : PhoneApplicationPage
    {
        private FacebookClient client;
        public LoginFacebook()
        {
            InitializeComponent();

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters["response_type"] = "token";
            parameters["display"] = "touch";
            parameters["scope"] = "user_about_me, friends_about_me, user_birthday, friends_birthday, publish_stream";
            parameters["redirect_uri"] = "https://www.facebook.com/connect/login_success.html";
            parameters["client_id"] = "votre appid";

            client = new FacebookClient();
            Uri uri = client.GetLoginUrl(parameters);

            wb.Visibility = Visibility.Visible;
            wb.Navigate(uri);
        }


        private void wb_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            FacebookOAuthResult result;
            if (client.TryParseOAuthCallbackUrl(e.Uri, out result))
            {
                if (result.IsSuccess)
                {
                    string token = result.AccessToken;
                    PhoneApplicationService.Current.State["token"] = token;
                    NavigationService.Navigate(new Uri("/PagePrincipale.xaml", UriKind.Relative));
                }
                wb.Visibility = Visibility.Collapsed;
            }
        }

        private void wb_NavigationFailed(object sender, System.Windows.Navigation.NavigationFailedEventArgs e)
        {
        }
    }
}