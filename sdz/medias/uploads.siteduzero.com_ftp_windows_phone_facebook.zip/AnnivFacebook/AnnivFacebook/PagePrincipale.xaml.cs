﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Globalization;
using Facebook;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Shell;
using System.Collections.ObjectModel;

namespace AnnivFacebook
{
    public partial class PagePrincipale : PhoneApplicationPage
    {
        public ObservableCollection<Utilisateur> UtilisateurList { get; set; }
        private FacebookClient facebookClient;

        public PagePrincipale()
        {
            InitializeComponent();

            UtilisateurList = new ObservableCollection<Utilisateur>();

            DataContext = this;
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            string token = (string)PhoneApplicationService.Current.State["token"];
            facebookClient = new FacebookClient(token);
            facebookClient.GetCompleted += facebookClient_GetCompleted;
            facebookClient.GetAsync("https://graph.facebook.com/me", null, "moi");

            base.OnNavigatedTo(e);
        }

        private void facebookClient_GetCompleted(object sender, FacebookApiEventArgs e)
        {
            if (e.Error == null)
            {
                if ((string)e.UserState == "moi")
                {
                    JsonObject data = (JsonObject)e.GetResultData();
                    string id = (string)data["id"];
                    string prenom = (string)data["first_name"];
                    string nom = (string)data["last_name"];
                    Dispatcher.BeginInvoke(() =>
                    {
                        imageUtilisateur.Source = new BitmapImage(new Uri("https://graph.facebook.com/" + id + "/picture"));
                        nomUtilisateur.Text = prenom + " " + nom;
                        dateNaissanceUtilisateur.Text = ObtientDateDeNaissance(data);
                    });

                    facebookClient.GetAsync("https://graph.facebook.com/me/friends", null, "amis");
                }
                if ((string)e.UserState == "amis")
                {
                    JsonObject data = (JsonObject)e.GetResultData();
                    JsonArray friends = (JsonArray)data["data"];
                    foreach (JsonObject f in friends)
                    {
                        string id = (string)f["id"];
                        facebookClient.GetAsync("https://graph.facebook.com/" + id, null, "detail");
                    }
                }
                if ((string)e.UserState == "detail")
                {
                    JsonObject data = (JsonObject)e.GetResultData();
                    string name = (string)data["name"];
                    string id = (string)data["id"];
                    Dispatcher.BeginInvoke(() => UtilisateurList.Add(new Utilisateur { Id = id, Nom = name, Image = new BitmapImage(new Uri("https://graph.facebook.com/" + id + "/picture")), DateNaissance = ObtientDateDeNaissance(data) }));
                }
            }
        }

        private string ObtientDateDeNaissance(JsonObject data)
        {
            if (data.ContainsKey("birthday"))
            {
                DateTime d;
                CultureInfo enUS = new CultureInfo("en-US");
                if (DateTime.TryParseExact((string)data["birthday"], "MM/dd/yyyy", enUS, System.Globalization.DateTimeStyles.None, out d))
                    return d.ToShortDateString();
            }
            return string.Empty;
        }
    }
}